/**
 * Narendar PT - Portfolio JavaScript
 * Includes: Typing animation, scroll animations, dynamic glow cards, 
 * interactive contact form, and mobile navigation controls.
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Menu Toggler
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileLinks = mobileMenu.querySelectorAll('a');

    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            const isExpanded = mobileMenuBtn.getAttribute('aria-expanded') === 'true';
            mobileMenuBtn.setAttribute('aria-expanded', !isExpanded);
            
            // Toggle menu visibility
            mobileMenu.classList.toggle('hidden');
            mobileMenu.classList.toggle('flex');
            
            // Toggle icon bars to X shape representation (optional transition inside SVG can be added)
            const iconPaths = mobileMenuBtn.querySelectorAll('svg path');
            if (iconPaths.length >= 2) {
                if (mobileMenu.classList.contains('hidden')) {
                    iconPaths[0].setAttribute('d', 'M4 6h16');
                    iconPaths[1].setAttribute('d', 'M4 12h16');
                    iconPaths[2].setAttribute('d', 'M4 18h16');
                } else {
                    iconPaths[0].setAttribute('d', 'M6 18L18 6M6 6l12 12');
                    iconPaths[1].setAttribute('d', '');
                    iconPaths[2].setAttribute('d', '');
                }
            }
        });

        // Close mobile menu when clicking any link
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.add('hidden');
                mobileMenu.classList.remove('flex');
                mobileMenuBtn.setAttribute('aria-expanded', 'false');
                const iconPaths = mobileMenuBtn.querySelectorAll('svg path');
                if (iconPaths.length >= 3) {
                    iconPaths[0].setAttribute('d', 'M4 6h16');
                    iconPaths[1].setAttribute('d', 'M4 12h16');
                    iconPaths[2].setAttribute('d', 'M4 18h16');
                }
            });
        });
    }

    // 2. Typing Subtitle Animation
    const typeTarget = document.getElementById('typing-text');
    if (typeTarget) {
        const textToType = "Fresher | Aspiring Full Stack Developer";
        let charIndex = 0;
        
        function type() {
            if (charIndex < textToType.length) {
                typeTarget.textContent += textToType.charAt(charIndex);
                charIndex++;
                setTimeout(type, 80); // Speed of typing in ms
            }
        }
        
        // Start typing animation with a small delay
        setTimeout(type, 1000);
    }

    // 3. Scroll Reveal Animation (Intersection Observer)
    const revealElements = document.querySelectorAll('.reveal-element');
    
    if (revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target); // Reveal once
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px' // Trigger slightly before element is in full view
        });

        revealElements.forEach(element => {
            revealObserver.observe(element);
        });
    }

    // 4. Navigation Spy (Highlight active nav link based on scroll position)
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    function highlightNavigation() {
        let scrollY = window.pageYOffset;
        
        sections.forEach(current => {
            const sectionHeight = current.offsetHeight;
            const sectionTop = current.offsetTop - 150; // offset for sticky header
            const sectionId = current.getAttribute('id');
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
    
    window.addEventListener('scroll', highlightNavigation);

    // 5. Glow Card Cursor Tracker (Glow Effect)
    const glowCards = document.querySelectorAll('.glow-card');
    
    glowCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left; // x position inside element
            const y = e.clientY - rect.top;  // y position inside element
            
            card.style.setProperty('--mouse-x', `${x}px`);
            card.style.setProperty('--mouse-y', `${y}px`);
        });
    });

    // 6. Interactive Contact Form Submission & Toast Feedback
    const contactForm = document.getElementById('contact-form');
    const toast = document.getElementById('toast');

    if (contactForm && toast) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();

            // Extract values
            const name = document.getElementById('form-name').value;
            const email = document.getElementById('form-email').value;
            const message = document.getElementById('form-message').value;

            if (!name || !email || !message) {
                showToast("Please fill in all fields.", "error");
                return;
            }

            // Simulated saving data / API submit
            console.log(`Mock form submit from ${name} (${email}): ${message}`);
            
            // Show custom Success Toast
            showToast(`Thank you, ${name}! Your message has been sent successfully.`, "success");
            
            // Reset form fields
            contactForm.reset();
        });
    }

    function showToast(message, type = "success") {
        const toastContent = toast.querySelector('.toast-content');
        const toastIcon = toast.querySelector('.toast-icon');
        
        if (toastContent && toastIcon) {
            toastContent.textContent = message;
            
            if (type === "success") {
                toast.classList.remove('border-red-500', 'bg-red-950/80');
                toast.classList.add('border-indigo-500', 'bg-indigo-950/80');
                toastIcon.innerHTML = `<svg class="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`;
            } else {
                toast.classList.remove('border-indigo-500', 'bg-indigo-950/80');
                toast.classList.add('border-red-500', 'bg-red-950/80');
                toastIcon.innerHTML = `<svg class="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`;
            }
        }
        
        // Animated reveal
        toast.classList.remove('translate-y-24', 'opacity-0');
        toast.classList.add('translate-y-0', 'opacity-100');

        // Hide toast after 4 seconds
        setTimeout(() => {
            toast.classList.add('translate-y-24', 'opacity-0');
            toast.classList.remove('translate-y-0', 'opacity-100');
        }, 4000);
    }
});
